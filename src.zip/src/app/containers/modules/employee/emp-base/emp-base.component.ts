import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-base',
  templateUrl: './emp-base.component.html',
  styleUrls: ['./emp-base.component.scss']
})
export class EmpBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
