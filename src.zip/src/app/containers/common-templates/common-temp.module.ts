import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './footer/footer.component';
import { BookingFormComponent } from './booking-form/booking-form.component';
import { CalendarModule } from 'primeng/calendar';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TimepickerModule } from 'ngx-bootstrap';
import { NiceSelectModule } from 'ng-nice-select';

@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    BookingFormComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    CalendarModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    NiceSelectModule
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    BookingFormComponent
  ]
})
export class CommonTempModule {}
